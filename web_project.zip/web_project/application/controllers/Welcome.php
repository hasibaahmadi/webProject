<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

	function __construct(){
        parent::__construct();
    }

	public function index(){
		$this->load->view('home');
	}
	public function info(){
		$this->load->view('info');
	}
	public function about(){
		$this->load->view('about');
	}
	public function contact(){
		$this->load->view('contact');
	}
	
	public function blog(){
		$this->load->Model('PostModel');
		$data['posts']=$this->PostModel->getPosts();
		$this->load->view('news',$data);
	}
}
