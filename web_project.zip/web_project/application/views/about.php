<?php require_once 'includes/header.php'; ?>
        <div class="inner-information-text">
            <div class="container">
               <h3>About</h3>
               <ul class="breadcrumb">
                  <li><a href="<?=base_url()?>Welcome">Home</a></li>
                  <li class="active">about</li>
               </ul>
            </div>
         </div>
      </section>
     
    
      <!-- <div class="matchs-info">
            <div class="col-md-6 col-sm-6 col-xs-12">
               <div class="row">
                  <div class="full">
                     <div class="matchs-vs">
                        <div class="vs-team">
                           <div class="team-btw-match">
                               <h2>Vision</h2>                                
                               <p>Having a free and progressive Afghanistan without discrimination, violence, and inter-religious coherence and convergence where all Afghans, men and women, can live in peace, social welfare and security.</p>    
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
            <div class="col-md-6 col-sm-6 col-xs-12">
               <div class="row">
                  <div class="full">
                     <div class="right-match-time">
                        <h2>Mission</h2>
                       <p>Participate in development processes, prosperity and rebuilding Afghanistan through sustained change, national and international experience innovations, the growth of democracy, social justice and the creation of group energy through the participation of all segments of society, including men, in sustaining progress, social welfare and self-support. Afghan sufficiency based on the principle of mutual respect and mutual respect.</p>
                     </div>
                  </div>
               </div>
            </div>
         </div> -->
      <section id="contant" class="contant main-heading" style="padding-bottom:0;margin-bottom:-1px;position:relative;z-index:1;">
         <div class="aboutus">
            <div class="container">
               <div class="row">
                  <div class="col-md-12 col-sm-12">
                     <div class="col-md-7 col-sm-7 col-xs-12">
                        <div class="full">
                           <h3>HASAS ORGANIZATION HISTORY</h3>
                           <p>Our country of Afghanistan has been plagued by wars for the last four decades for various reasons, which has destroyed the infrastructure of this country, which requires attention to identify these problems in order to bring prosperity and prosperity to our country and our people. To promote science, culture, civil liberties and citizenship.
                           </p>
                          <p>Fortunately, with the new transformation that has taken place in the last two decades by the friendly and international community, there is once again a golden opportunity for the people of Afghanistan to put Afghanistan on the path of transformation.Considering the current situation and the hope for a better tomorrow, the team of the Afghan Humanitarian Social and Innovative Service Institute, realizing its urgent needs and human responsibilities, has recognized its duty as a social institution in 1398 with the aim of transforming personal and social life. Create every Afghan in the sectors of social services and livelihoods, education, health and agriculture</p>
                           <p>It is a non-profit, non-political organization that does not belong to any particular group or party and is comprised of creative and innovative young people who aim to change the quality and quantity of life and social welfare and to participate in development, reconstruction and development. Afghanistan is sustained by sustainable development, growth of democracy, social justice and the creation of group energy through the participation of all segments of society in sustaining the advancement of social welfare and supporting Afghan self-sufficiency based on the principle of mutual respect and mutual respect.</p>
                        </div>
                     </div>
                     <div class="col-md-5 col-sm-5 col-xs-12">
                        <img class="img-responsive" src="<?=base_url()?>images/bg1.png" alt="#" />
                        <br>
                        <hr>
                        <br>
                        <div class="content-widget top-story" style="background: url(<?=base_url()?>images/top-story-bg.jpg);">
                                <div class="top-stroy-header">
                                   <h2 class="fa fa-fa fa-angle-right">     Values </h2>
                                   <span class="date">________________________</span>
                                   <h2>Our Values</h2>
                                </div>
                                <ul class="other-stroies">
                                   <li><a href="#demo" data-toggle="collapse">Responsibility</a></li>
                                   <div class="collapse_continer_div">
                                       <div id="demo" class="collapse" >
                                            We are committed to individual and organizational responsibility, using resources effectively, delivering satisfying and responsive results to our people, government, and partner organizations.
                                       </div>
                                   </div>
                                   <li><a href="#demo1" data-toggle="collapse">Honesty</a></li>
                                   <div class="collapse_continer_div">
                                           <div id="demo1" class="collapse">
                                                   Honesty in doing things and transparency in serving our priorities.                                </div>
                                       </div>
                                   <li><a href="#demo2" data-toggle="collapse">Cooperation</a></li>
                                   <div class="collapse_continer_div">
                                           <div id="demo2" class="collapse">
                                                   Respect each other's values by sharing efforts to make positive changes and improvements.                                </div>
                                       </div>
                                   <li><a href="#demo3" data-toggle="collapse">Equality</a></li>
                                   <div class="collapse_continer_div">
                                           <div id="demo3" class="collapse">
                                                   We believe in equality and equality, that good mutual respect is our top priority. Progress and positive changes are unveiled through equality.                                </div>
                                       </div>
                                   <li><a href="#demo4" data-toggle="collapse">Development</a></li>
                                   <div class="collapse_continer_div">
                                           <div id="demo4" class="collapse">
                                                   We are committed to higher education, scientific and experiential performances in order to unveil our continued progress and impact.                                </div>
                                       </div>
                                   <li><a href="#demo5" data-toggle="collapse">Transparency</a></li>
                                   <div class="collapse_continer_div">
                                           <div id="demo5" class="collapse">
                                                   We consider ourselves accountable in reporting and transparency of our workflow, sharing business results and useful experiences is our top priority.
                                           </div>
                                       </div>
                                   <li><a href="#demo6" data-toggle="collapse">Democracy</a></li>
                                   <div class="collapse_continer_div">
                                           <div id="demo6" class="collapse">
                                                   We believe in democracy and democracy, for social justice, human rights and all forms of oppression, racial, religious, religious and regional discrimination.                                </div>
                                       </div>
                                   <li><a href="#demo7" data-toggle="collapse">Variety</a></li>
                                   <div class="collapse_continer_div">
                                           <div id="demo7" class="collapse">
                                                   We believe in unity and together we can solve the biggest problems.                                </div>
                                       </div>
                                   <li><a href="#demo8" data-toggle="collapse">Creativity</a></li>
                                   <div class="collapse_continer_div" >
                                           <div id="demo8" class="collapse" >
                                                   We embrace innovation, positive innovation and change, and are committed to implementing national and international experienced innovation to drive continued change.                                </div>
                                       </div>
                                   <li><a href="#demo9" data-toggle="collapse">Bilateral work</a></li>
                                   <div class="collapse_continer_div">
                                           <div id="demo9" class="collapse">
                                               For the growth and development of society, it is necessary for all strata to participate in a social development process, we believe in the principle of dual work in promoting humanitarian activities.                                
                                           </div>
                                   </div>
                               
                                </ul>
                             </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
         <div class="dark-section" style="background:url(<?=base_url()?>images/walle.jpg)">
            <div class="container">
               <div class="row">
                  <div class="col-md-12 col-sm-12">
                     <div class="heading-main">
                        <h2>Vision</h2>
                     </div>
                     <div class="testimonial-slider">
                        <div class="carousel slide" data-ride="carousel" id="quote-carousel">
                           <!-- Carousel Slides / Quotes -->
                           <div class="carousel-inner text-center">
                              <!-- Quote 1 -->
                              <div class="item active">
                                 <blockquote>
                                    <div class="row">
                                       <div class="col-sm-10 col-sm-offset-1">
                                          <p> Having a free and progressive Afghanistan without discrimination, violence, and inter-religious coherence and convergence where all Afghans, men and women, can live in peace, social welfare and security.</p>
                                          <small></small>
                                       </div>
                                    </div>
                                 </blockquote>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
            <hr><br><hr>
            <div class="container">
                        <div class="row">
                           <div class="col-md-12 col-sm-12">
                              <div class="heading-main">
                                 <h2>Mission</h2>
                              </div>
                              <div class="testimonial-slider">
                                 <div class="carousel slide" data-ride="carousel" id="quote-carousel">
                                    <!-- Carousel Slides / Quotes -->
                                    <div class="carousel-inner text-center">
                                       <!-- Quote 1 -->
                                       <div class="item active">
                                          <blockquote>
                                             <div class="row">
                                                <div class="col-sm-10 col-sm-offset-1">
                                                   <p> Participate in development processes, prosperity and rebuilding Afghanistan through sustained change, national and international experience innovations, the growth of democracy, social justice and the creation of group energy through the participation of all segments of society, including men, in sustaining progress, social welfare and self-support. Afghan sufficiency based on the principle of mutual respect and mutual respect.</p>
                                                   <small></small>
                                                </div>
                                             </div>
                                          </blockquote>
                                       </div>
                                      
                                    </div>
                                    
                                </div>
                              </div>
                           </div>
                        </div>
                </div>

             
        </div>
         
      </div>
      </section>
     

<?php require_once 'includes/footer.php'; ?>