
<?php require_once 'includes/header.php'; ?>
         
         <div class="inner-information-text">
            <div class="container">
               <h3>Info</h3>
               <ul class="breadcrumb">
                  <li><a href="<?=base_url()?>Welcome">Home</a></li>
                  <li class="active">Info</li>
               </ul>
            </div>
         </div>
      </section>

      <section id="contant" class="contant main-heading team">
         <div class="row">
            <div class="container">
               <div class="col-md-9">
                  <div class="feature-post">
                     <div class="feature-img">
                        <img src="<?=base_url()?>images/img-01_002.jpg" class="img-responsive" alt="info image" />
                     </div>
                     <div class="feature-cont">
                        <div class="post-people">
                           <div class="left-profile">
                              <span class="share"></span>
                           </div>
                        </div>
                     </div>
                  </div>
                  <div class="feature-post small-blog">
                     <div class="col-md-5">
                        <div class="feature-img">
                           <img src="<?=base_url()?>images/info.jpg" class="img-responsive" alt="ahsas image" />
                        </div>
                     </div>
                     <div class="col-md-7">
                        <div class="feature-cont">
                          
                           <div class="post-heading">
                              <h3>Afghan Humanitarian Social and Ambition Services – Organization.</h3>
                              <p>It is a non-profit, non-political organization that does not belong to any particular group or party and is comprised of creative and innovative young people who aim to change the quality and quantity of life and social welfare and to participate in development, reconstruction and development. Afghanistan is sustained by sustainable development, growth of democracy, social justice and the creation of group energy through the participation of all segments of society in sustaining the advancement of social welfare and supporting Afghan self-sufficiency based on the principle of mutual respect and mutual respect.</p>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </section>
    
<?php require_once 'includes/footer.php'; ?>